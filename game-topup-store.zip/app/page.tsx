import GameTopupStore from "@/components/game-topup-store"

export default function Home() {
  return <GameTopupStore />
}

